import setuptools

long_description = ''' VoiceMath
'''

required = [
    'idx2numpy',
    'imageio',
    'imutils',
    'matplotlib',
    'numpy',
    'tensorflow',
    'bison',
    'ply',
    'opencv-python',
    'h5py',
    'Markdown',
    'Pillow',
    'ply',
    'tensorflow<2.11',
    'twine',
]

try:
    setuptools.setup(
        name='voicemath',
        version='1.0.0',
        long_description=long_description,
        author='late',
        description=' Software para la lectura de expresiones matemáticas básicas mediante Machine Learning',
        author_email='',
        packages=setuptools.find_packages(),
        install_requires=required,
        include_package_data=True,
        python_requires='>=3.6'
    )
except Exception as e:
    pass
